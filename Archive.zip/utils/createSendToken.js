const jwt = require("jsonwebtoken");

const signToken = (id, role) => {
  return jwt.sign({ id: id, role: role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN,
  });
};

exports.createSendToken = (user, message, statusCode, res) => {
  const token = signToken(user._id, user.role);

  const cookieOptions = {
    httpOnly: true,
    secure: false, // Temporarily disable for testing
     sameSite: "none",
    secure: true,
    expires: new Date(
      Date.now() +
        process.env.JWT_COOKIE_EXPIRES_IN * 24 * 60 * 60 * 1000 * 1000
    ),
  };

  if (process.env.NODE_ENV === "production") cookieOptions.secure = true;

  res.cookie("jwt", token, cookieOptions);

  user.password = undefined;
  const data = {
    status: "success",
    message,
    token,
    data: {
      user,
    },
  };

  res.status(statusCode).json(data);
};
